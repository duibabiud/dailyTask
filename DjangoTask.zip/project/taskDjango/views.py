from django.shortcuts import render
from django.http import HttpResponse
import imaplib
import email
import os
from django.contrib import messages
from .models import Users
from django.contrib.auth.models import User, auth
from django.shortcuts import redirect

def login(request):
    if request.method == 'POST':
        user = request.POST['email']
        password = request.POST['password']
        imap_url = 'imap.outlook.com'

        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attachment_dir = os.path.join(BASE_DIR, 'taskDjango/static/downloads')
        con = imaplib.IMAP4_SSL(imap_url)
        con.login(user, password)
        con.select('Inbox')

        type, msgs = con.search(None,'UNSEEN', '(SUBJECT "Resume")')
        msgs = msgs[0].split()
        count = 0

        for msg in msgs:
            resp, data = con.fetch(msg, "(RFC822)")
            email_body = data[0][1]
            m = email.message_from_bytes(email_body)

            if m.get_content_maintype() != 'multipart':
                continue

            for part in m.walk():
                if part.get_content_maintype() == 'multipart':
                    continue
                if part.get('Content-Disposition') is None:
                    continue

                filename = part.get_filename()
                if filename is not None:
                    save_path = os.path.join(attachment_dir, filename)
                    if not os.path.isfile(save_path):
                        count += 1
                        fp = open(save_path, 'wb')
                        fp.write(part.get_payload(decode=True))
                        fp.close()
        #print("{} Files downloaded".format(count))
        #user = User.objects.create_user(username = email, path = attachment_dir)
        #user.save()
        #return HttpResponse("{} files downloaded".format(count))
        return render(request, 'index.html', { 'files' : count })
        #messages.info(request, "{} files downloaded".format(count))

    else:
        return render(request, 'index.html')