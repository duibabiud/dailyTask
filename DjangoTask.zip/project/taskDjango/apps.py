from django.apps import AppConfig


class TaskdjangoConfig(AppConfig):
    name = 'taskDjango'
